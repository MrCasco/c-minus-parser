from enum import Enum

class TipoExpresion(Enum):
    Op = 0
    Const = 1
    Int = 2
    Void = 3
